var express = require('express');
var router = express.Router();
var db = require("../database/mongo");
var User = require("../Models/User")(db);
var Book = require("../Models/Book")(db);

/* GET api listing. */
router.get('/', function (req, res, next) {
    res.send(null);
});

router.get('/users/', function (req, res, next) {
    var users = null;
    User.find({}, "", function (err, us) {
        users = us;
        res.json(us);
    });
});

router.get('/books/', function (req, res, next) {
    Book.find({}, "", function (err, us) {
        res.json(us);
    });
});


module.exports = router;
